var scroll = new SmoothScroll('a[href*="#"]');
